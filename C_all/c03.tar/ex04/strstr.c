/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   strstr.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gclement <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 12:29:10 by gclement          #+#    #+#             */
/*   Updated: 2022/07/18 09:12:48 by gclement         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
char	*ft_strstr(char *str, char *to_find)
{
	int		i;
	int		x;
	char	*temp;

	i = 0;
	x = 0;
	while (str[i])
	{
		while (str[i] == to_find[x])
		{
			if (x == 0)
				temp = &str[i];
			x++;
			i++;
			if (to_find[x] == '\0')
				return (temp);
		}
	i++;
	x = 0;
	}
	return (0);
}
