/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gclement <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 11:41:16 by gclement          #+#    #+#             */
/*   Updated: 2022/07/18 09:10:09 by gclement         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	int				i;
	unsigned int	x;

	x = 0;
	i = 0;
	while (dest[i] != '\0')
	{
		while (dest[i + 1] == '\0' && src[x] && x < nb)
		{
			dest[i + 1] = src[x];
			x++;
			i++;
		}
		i++;
	}
	return (dest);
}
