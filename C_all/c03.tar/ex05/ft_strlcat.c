/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gclement <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/14 13:07:53 by gclement          #+#    #+#             */
/*   Updated: 2022/07/18 09:23:13 by gclement         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	x;

	x = 0;
	i = 0;
	while (dest[i])
	{
		while (dest[i + 1] == '\0' && src[x] &&  i <  size - 1)
		{
			if (x  == size)
			{
				dest[i] = '\0';
				return (i);
			}
			dest[i + 1] = src[x];
			x++;
			i++;
		}
		i++;
	}
	return (i);
}
