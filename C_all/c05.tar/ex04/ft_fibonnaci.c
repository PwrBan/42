/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fibonnaci.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gclement <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 22:03:52 by gclement          #+#    #+#             */
/*   Updated: 2022/07/18 22:58:07 by gclement         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
int	ft_fibonnacci(int index)
{
	if(index <= 0)
		return (-1);
	if(index < 2)
		return index;
	return (ft_fibonnacci(index - 1) + ft_fibonnacci(index - 2));
}
