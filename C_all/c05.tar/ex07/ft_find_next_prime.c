/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gclement <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/19 15:34:08 by gclement          #+#    #+#             */
/*   Updated: 2022/07/19 16:24:26 by gclement         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
int	ft_is_prime(int nb)
{
	int	mod;
	int	div;

	div = 2;
	mod  = 1;
	if (nb <=  0 || nb == 1)
		return (0);
	while (div <= nb /div)
	{
		mod = nb % div;
		if (mod == 0)
			return (0);
		div++;
	}
	return(1);
}

int	ft_find_next_prime(int nb)
{
	int i;

	i = 0;
	while (i != 1)
	{
		if (ft_is_prime(nb))
			return (nb);
		nb++;
	}
	return (0);
}
