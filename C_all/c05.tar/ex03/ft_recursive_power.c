/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gclement <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 15:49:59 by gclement          #+#    #+#             */
/*   Updated: 2022/07/18 21:57:04 by gclement         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
int	ft_recursive_power(int nb, int power)
{
		if(power <= 0 || nb <= 0)
			return (1);
		if(power == 1)
			return (nb);
		return (nb * ft_recursive_power(nb, power - 1));
}
