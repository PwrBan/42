/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gclement <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 13:35:01 by gclement          #+#    #+#             */
/*   Updated: 2022/07/18 14:08:36 by gclement         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
int	ft_iterative_factorial(int nb)
{
	int i;
	int x;
	int result;

	i = 1;
	x = 2;
	result = i * x;
	if(nb <= 1)
		return(0);	
	while(x < nb)
	{
		x++;
		result *= x;
	}
	return result;
}
