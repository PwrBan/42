/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gclement <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 11:11:46 by gclement          #+#    #+#             */
/*   Updated: 2022/07/14 15:30:15 by gclement         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
void	ft_putchar(char ptr)
{
	write(1, &ptr, 1);
}

void	ft_pustr_non_printable(char *str)
{
	int				i;
	unsigned char	temp;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] < 32 || str[i] > 126)
		{
			temp = str[i];
			ft_putchar('\\');
			ft_putchar("0123456789abcdef"[temp / 16]);
			ft_putchar("0123456789abcdef"[temp % 16]);
		}
		else
			ft_putchar(str[i]);
		i++;
	}
}
