/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gclement <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/20 05:30:57 by gclement          #+#    #+#             */
/*   Updated: 2022/07/20 17:13:57 by gclement         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	base_is_valid(char *base)
{
	int	i;
	int	j;

	while(base[i] != '\0')
	{

	}
}

void	ft_putnbr_base(int nbr, char *base)
{
	if(nbr <= -2147483648)
		write(1, "-2147483648", 11);
	else if(nbr < 0)
	{
		nbr = nbr * -1;
		ft_putchar('-');
		ft_putnbr_base(nbr / 10, base);
	}
	else if(nbr > 9)
		ft_putnbr_base(nbr / 10, base);
	ft_putchar(base[nbr / 16]);
}

int main()
{
    char base[30] = "0123456789ABCDEF";
    int    nbr = -123456;
    ft_putnbr_base(nbr, base);
}
