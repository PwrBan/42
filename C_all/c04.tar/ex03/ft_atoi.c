/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gclement <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/15 21:39:53 by gclement          #+#    #+#             */
/*   Updated: 2022/07/18 13:23:20 by gclement         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
int check_char(char str)
{
	if(str == ' ')
		return (1);
	else if(str == '\r')
		return (1);
	else if(str == '\f')
		return (1);
	else if(str == '\v')
		return (1);
	else if(str == '\n')
		return (1);
	else if(str == '\t')
		return (1);

	return (0);
}
int	ft_atoi(char *str)
{
	int i;
	int sign;
	int nb;

	i = 0;
	sign = 1;
	nb = 0;
	while(check_char(str[i]))
		i++;
	while(str[i] == '+' || str[i] == '-')
	{	
		if(str[i] == '-')
			sign *= -1;
		i++;
	}
	while(str[i] >= '0' && '9' >= str[i])
	{
		nb = nb * 10 + (str[i] - '0');
		i++;
	}
	nb *= sign;
	return (nb);
}
