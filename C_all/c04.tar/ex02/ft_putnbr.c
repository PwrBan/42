/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gclement <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/15 10:02:39 by gclement          #+#    #+#             */
/*   Updated: 2022/07/20 09:20:16 by gclement         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}
void	ft_putnbr(int nb)
{
	if(nb <= -2147483648)
		write(1, "-2147483648", 11);
	else if(nb < 0)
	{
		nb = nb * -1;
		ft_putchar('-');
		ft_putnbr(nb / 10);
	}
	else if(nb > 9)
		ft_putnbr(nb / 10);
	ft_putchar(nb % 10 + '0');
}
