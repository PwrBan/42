/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_params.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gclement <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/19 23:20:21 by gclement          #+#    #+#             */
/*   Updated: 2022/07/19 23:33:27 by gclement         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdio.h>
int	main(int argc, char **argv)
{
	int i;
	int j;

	j = 0;
	i = argc - 1;
	while(i != 0)
	{
		while(argv[i][j] != '\0')
		{	
			write(1, &argv[i][j], 1);
			j++;
		}
		write(1, "\n", 1);
		j = 0;
		i--;
	}
}
