#include <unistd.h>
int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while (s1[i] || s2[i])
	{
		if (s1[i] > s2[i])
		{
			return (1);
		}
		else if (s1[i] < s2[i])
		{
			return (-1);
		}
		i++;
	}
	return (0);
}
void	ft_sort_params_tab(char **argv, int size)
{
	int	i;
	int	j;
	char	*temp;

	i = 1;
	while (i <= size)
	{
		j = 2;
		while (j < size)
		{
			if (ft_strcmp(argv[j - 1], argv[j]) == 1)
			{
				temp = argv[j - 1];
				argv[j - 1] = argv[j];
				argv[j] = temp;
			}
			j++;
		}
		i++;
	}
}

void	ft_put_params(int argc, char **argv)
{
	int i;
	int j;
	(void) argc;

	j = 0;
	i = 1;
	while(argv[i])
	{
		while(argv[i][j] != '\0')
		{
			write(1, &argv[i][j], 1);
			j++;
		}
		write(1, "\n", 1);
		j = 0;
		i++;
	}
}

int	main(int argc, char **argv)
{
	ft_sort_params_tab(argv, argc);
	ft_put_params(argc, argv);
}
